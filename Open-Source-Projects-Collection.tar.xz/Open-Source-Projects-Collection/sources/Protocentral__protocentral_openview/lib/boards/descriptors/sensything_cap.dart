// Copyright (c) 2024-2026 protocentral
// SPDX-License-Identifier: MIT

import '../board_descriptor.dart';
import '../channel_spec.dart';
import '../decoders/sensything_cap_decoders.dart';
import '../packet_spec.dart';
import '../transport_profile.dart';

/// Sensything CAP — 4-channel capacitive sensing front-end.
///
/// Wire format: 0x0A | 0xFA | len_LSB | len_MSB | 0x02 | <8 bytes> | 0x0B
/// Payload: 4 × int16 LE. BLE and USB are byte-identical.
final BoardDescriptor sensythingCapDescriptor = BoardDescriptor(
  id: 'sensything_cap',
  displayName: 'Sensything CAP',
  manufacturer: 'ProtoCentral',
  transports: const TransportSupport(usb: true, ble: true, wifi: true),
  usbProfile: const UsbProfile(
    baudRate: 115200,
  ),
  // Shared OpenView-compatible Sensything BLE service. Service/characteristic
  // assumed identical to Sensything OX; advertised name inferred as
  // 'Sensything-CAP'. TODO: confirm against the CAP firmware (SensythingBLE.cpp).
  bleProfile: const BleProfile(
    serviceUuid: '0001A7D3-D8A4-4FEA-8174-1736E808C066',
    streamCharacteristicUuid: '0002A7D3-D8A4-4FEA-8174-1736E808C066',
    nameAdvertisesContains: ['Sensything-CAP'],
  ),
  channels: const [
    ChannelSpec(
      id: 'ch1',
      label: 'Channel 1',
      sampleRateHz: 100,
      unit: SignalUnit.adc,
      kind: ChannelKind.capacitance,
    ),
    ChannelSpec(
      id: 'ch2',
      label: 'Channel 2',
      sampleRateHz: 100,
      unit: SignalUnit.adc,
      kind: ChannelKind.capacitance,
    ),
    ChannelSpec(
      id: 'ch3',
      label: 'Channel 3',
      sampleRateHz: 100,
      unit: SignalUnit.adc,
      kind: ChannelKind.capacitance,
    ),
    ChannelSpec(
      id: 'ch4',
      label: 'Channel 4',
      sampleRateHz: 100,
      unit: SignalUnit.adc,
      kind: ChannelKind.capacitance,
    ),
  ],
  packets: [
    PacketSpec(
      pktType: 2,
      label: '4ch capacitance',
      expectedPayloadLength: 8,
      decode: decodeSensythingCapPkt2,
    ),
  ],
  notes: '4-channel capacitive front-end. BLE and USB share the same packet format (see SensythingBLE.cpp:142).',
);
