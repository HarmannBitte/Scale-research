// Copyright (c) 2024-2026 protocentral
// SPDX-License-Identifier: MIT

import '../board_descriptor.dart';
import '../channel_spec.dart';
import '../decoders/max86150_decoders.dart';
import '../packet_spec.dart';
import '../transport_profile.dart';

final BoardDescriptor max86150Descriptor = BoardDescriptor(
  id: 'max86150',
  displayName: 'MAX86150 Breakout',
  manufacturer: 'ProtoCentral',
  transports: const TransportSupport(usb: true),
  usbProfile: const UsbProfile(
    baudRate: 115200,
  ),
  channels: const [
    ChannelSpec(
      id: 'ecg',
      label: 'ECG',
      sampleRateHz: 200,
      unit: SignalUnit.adc,
      kind: ChannelKind.ecg,
    ),
    ChannelSpec(
      id: 'ppgRed',
      label: 'PPG (Red)',
      sampleRateHz: 200,
      unit: SignalUnit.adc,
      kind: ChannelKind.ppg,
    ),
    ChannelSpec(
      id: 'ppgIr',
      label: 'PPG (IR)',
      sampleRateHz: 200,
      unit: SignalUnit.adc,
      kind: ChannelKind.ppg,
    ),
  ],
  packets: [
    PacketSpec(
      pktType: 2,
      label: 'ECG/PPG Red+IR',
      expectedPayloadLength: 6,
      decode: decodeMax86150Pkt2,
    ),
  ],
  notes: 'Maxim MAX86150 integrated single-lead ECG (18-bit) and dual-LED '
      'PPG (18-bit Red + IR) AFE. ECG and PPG share the same packet.',
);
